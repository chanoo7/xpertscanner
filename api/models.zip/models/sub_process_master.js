'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class SubProcessMaster extends Model {
    static associate(models) {
      // Correct association: SubProcessMaster belongs to ProcessMaster using StyleProcessID
      SubProcessMaster.belongsTo(models.ProcessMaster, {
        foreignKey: 'StyleProcessID',  // Foreign key in SubProcessMaster
        targetKey: 'StyleProcessID',   // Primary key in ProcessMaster
        as: 'parentProcess'            // Alias to be used in include
      });
    }
  }

  SubProcessMaster.init({
    StyleProcessID: {
      type: DataTypes.INTEGER,
      primaryKey: true,
    },
    ProcessID: {
      type: DataTypes.INTEGER,
      primaryKey: true,
    },
    ProcessName: DataTypes.STRING(512),
    SlNo: DataTypes.INTEGER,
    SkillName: DataTypes.STRING(512),
    ProcessGroupName: DataTypes.STRING(512),
    ReferenceDetailsName: DataTypes.STRING(512),
    MachineName: DataTypes.STRING(512),
    CycleTime: DataTypes.DOUBLE,
  }, {
    sequelize,
    modelName: 'SubProcessMaster',
    tableName: 'sub_process_master',
    timestamps: false,
    uniqueKeys: {
      unique_process: {
        fields: ['StyleProcessID', 'ProcessID'],
      }
    }
  });

  return SubProcessMaster;
};
