'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class RouteMaster extends Model {
    static associate(models) {
      RouteMaster.belongsTo(models.StyleMaster, {
        foreignKey: 'StyleID',
        as: 'style'
      });

      RouteMaster.hasMany(models.ProcessMaster, {
        foreignKey: 'StyleRouteMapID',
        as: 'processes'
      });
    }
  }

  RouteMaster.init({
    StyleID: {
      type: DataTypes.INTEGER,
      primaryKey: true,
    },
    StyleRouteMapID: {
      type: DataTypes.INTEGER,
      primaryKey: true,
    },
    Descriptions: DataTypes.STRING(512),
  }, {
    sequelize,
    modelName: 'RouteMaster',
    tableName: 'route_master',
    timestamps: false,
    uniqueKeys: {
      unique_style_routemap: {
        fields: ['StyleID', 'StyleRouteMapID'],
      }
    }
  });

  return RouteMaster;
};
