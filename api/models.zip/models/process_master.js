'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class ProcessMaster extends Model {
    static associate(models) {
      ProcessMaster.belongsTo(models.RouteMaster, {
        foreignKey: 'StyleRouteMapID',
        as: 'route'
      });

      // Correct association with SubProcessMaster using StyleProcessID
      ProcessMaster.hasMany(models.SubProcessMaster, {
        foreignKey: 'StyleProcessID', // Foreign key in SubProcessMaster
        sourceKey: 'StyleProcessID',  // Primary key in ProcessMaster
        as: 'subProcesses'            // Alias to be used in include
      });
    }
  }

  ProcessMaster.init({
    StyleRouteMapID: {
      type: DataTypes.INTEGER,
      primaryKey: true,
    },
    StyleProcessID: {
      type: DataTypes.INTEGER,
      primaryKey: true,
    },
    StageID: DataTypes.INTEGER,
    ProcessID: DataTypes.INTEGER,
    ProcessName: DataTypes.STRING(512),
    SlNo: DataTypes.INTEGER,
    SkillName: DataTypes.STRING(512),
    ProcessGroupName: DataTypes.STRING(512),
    ReferenceDetailsName: DataTypes.STRING(512),
    MachineName: DataTypes.STRING(512),
    CycleTime: DataTypes.STRING(512),
  }, {
    sequelize,
    modelName: 'ProcessMaster',
    tableName: 'process_master',
    timestamps: false,
    uniqueKeys: {
      unique_style_process: {
        fields: ['StyleRouteMapID', 'StyleProcessID'],
      }
    }
  });

  return ProcessMaster;
};
