'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class StyleMaster extends Model {
    static associate(models) {
      StyleMaster.hasMany(models.RouteMaster, {
        foreignKey: 'StyleID',
        as: 'routes'
      });
    }
  }

  StyleMaster.init({
    StyleID: {
      type: DataTypes.INTEGER,
      primaryKey: true,
    },
    StyleStockID: DataTypes.INTEGER,
    KHStyleNo: DataTypes.STRING(512),
    KHStyleDescription: DataTypes.STRING(512),
    ColorName: DataTypes.STRING(512),
  }, {
    sequelize,
    modelName: 'StyleMaster',
    tableName: 'style_master',
    timestamps: false,
  });

  return StyleMaster;
};
